package com.example.uts_2301082011_b

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
